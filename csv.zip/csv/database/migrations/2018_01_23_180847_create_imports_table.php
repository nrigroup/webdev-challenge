<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateImportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('imports', function (Blueprint $table) {
            
            $table->increments('id');
            $table->date('date');
            $table->text('category');
            $table->text('lot title');
            $table->text('lot location');
            $table->text('lot condition');
            $table->decimal('pre-tax amount',10,2);
            $table->text('tax name');
            $table->decimal('tax amount',10,2);
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('imports');
    }
}
