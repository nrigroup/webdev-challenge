@extends('layouts.master')

@section('content')
    <div class="container">

        <div class="panel panel-default">
            <div class="panel-heading">Data saved successfully</div>

            <div class="panel-body">                                           
                <div class="form-group">
                    <div class="col-md-5 col-md-offset-5">
                        <button type="submit" class="btn btn-primary" data-toggle="collapse" data-target="#demo">
                            Spending Summary

                        </button>
                    </div>                                                          
                </div>               
            </div>

            <div class="panel-body">  
                
                <div id="demo" class="collapse">

                    <table class="table table-striped">

                        <tr>
                            <th>Month</th><th>Category</th><th>Total</th>
                        </tr>

                        @foreach($data as $record)

                        <tr>
                            <td>{{$record->month}}</td>
                            <td>{{$record->category}}</td>
                            <td>{{$record->sum}}</td>
                        </tr>

                        @endforeach

                        <tr>
                            <td colspan="2"><strong>Total</strong></td>
                            <td><strong>{{$total}}</strong></td>
                        </tr>

                    </table>

                </div> 
                
            </div> 
        </div>
    </div>
@endsection

