@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">Data uploaded successfully</div>

            <div class="panel-body">

                <form class="form-horizontal" method="POST" action={{url('/store')}} enctype="multipart/form-data">
                    {{ csrf_field() }}

                    <div class="form-group">
                        <div class="col-md-5 col-md-offset-5">
                            
                            <button type="submit" class="btn btn-primary">
                                Import to Database
                            </button>
                            
                        </div>
                        <div class="col-md-5 col-md-offset-5">
                            
                            <input type="hidden" class="btn btn-primary" name="serializedData" value="{{$serializedData}}"/>
                            
                        </div>
                    </div>
                </form>                                    
            </div>

            <div class="panel-body">                               

                    <table class="table table-striped">

                        <tr>
                            @foreach($header as $title)
                            <th>{{$title}}</th>
                            @endforeach                                    
                        </tr>

                        @foreach($data as $record)
                        <tr>                                    
                            @foreach($record as $field)
                             <td>{{$field}}</td>

                            @endforeach
                        </tr>
                        @endforeach

                    </table>

            </div>
        </div>
    </div>
@endsection

