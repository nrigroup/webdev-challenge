<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">Data uploaded successfully</div>

            <div class="panel-body">

                <form class="form-horizontal" method="POST" action=<?php echo e(url('/store')); ?> enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <div class="col-md-5 col-md-offset-5">
                            
                            <button type="submit" class="btn btn-primary">
                                Import to Database
                            </button>
                            
                        </div>
                        <div class="col-md-5 col-md-offset-5">
                            
                            <input type="hidden" class="btn btn-primary" name="serializedData" value="<?php echo e($serializedData); ?>"/>
                            
                        </div>
                    </div>
                </form>                                    
            </div>

            <div class="panel-body">                               

                    <table class="table table-striped">

                        <tr>
                            <?php $__currentLoopData = $header; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($title); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                        </tr>

                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>                                    
                            <?php $__currentLoopData = $record; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <td><?php echo e($field); ?></td>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>