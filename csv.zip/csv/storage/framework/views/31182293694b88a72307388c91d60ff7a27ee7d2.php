<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Data uploaded successfully</div>

                    <div class="panel-body">                                           
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" data-toggle="collapse" data-target="#demo">
                                    Data Table
                                    
                                </button>
                            </div>                                                          
                        </div>               
                    </div>
                    
                    <div class="panel-body">                               
                        <div id="demo" class="collapse">
                            
                            <table class="table table-striped">

                                <tr>
                                    <th><?php echo e($header[0]</th><th>Category</th><th>Total</th>
                                    
                                </tr>

                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td>{{$record[0]); ?></td>
                                    <td><?php echo e($record[1]); ?></td>
                                    <td><?php echo e($record[2]); ?></td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td colspan="2"><strong>Total</strong></td>
                                    <td><strong><?php echo e($total); ?></strong></td>
                                </tr>

                            </table>
                            
                        </div> 
                    </div> 
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>