  @extends("layout.template")

  @section('content')

  <div class="container">
	<div class="row">
	<div class="col-md-6 col-md-offset-3 jumbotron">
	<h4>Upload Form</h4><br/>
	  <div class="well text-center">
	  <div style="display:none;" class="alert alert-danger" id="alert"></div>
	    <form class="form-inline" method="post" action="submitUpload" enctype="multipart/form-data">
	      <div class="form-group">
	          <label for="file" class="btn btn-lg btn-default">Please browse your file</label>
	         <input style="display:none" type="file" name="file" id="file">
	      </div><br/><br/>
	        {{ csrf_field() }}
	      <input type="submit" value="upload" class="btn btn-success"/>
	      </form>
  		
          </div>  
  		</div>

 <table class='table table-hover'>
 

  </table>

  	</div>
</div>

@endsection	
	
@push("js")
<script src="{{ asset('public/js/upload.js') }}"></script>
@endpush