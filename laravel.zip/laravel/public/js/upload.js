$(document).ready(function(){

$("input[type=submit]").on("click",function(e){
        e.preventDefault();

    var file = $("input[type=file]")[0].files[0];
    
    var formData = new FormData();
    formData.append("file",file);

    $.ajax({
    	 headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url:"submitUpload",
        type:"post",
        contentType: false,
        processData: false,
        data:formData,
        success:function(data){
        //parsing data into json format
        var data = JSON.parse(data);
     
        var html = "";
            html += "<thead><tr><th>Date</th><th>Category</th><th>Tax Amount</th></tr></thead>";
       
        $.each(data,function(index,value){
          
         html +=  "<tbody><tr><td>"+value.date+"</td><td>"+value.category+"</td>"+
                   "<td>"+value.category+"</td></tr></tbody>";             

       });// each function

       $("table").append(html);

        }

    });


    });

});