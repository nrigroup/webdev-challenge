<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\file;
use DB;


class uploadController extends Controller
{

    public function getIndex(){
       
       return view("upload");

    }

   
   public function submitUpload(Request $request){
      
      if($request->intersect('file')){
          
          $requestFile = $request->file('file');

			 if ($requestFile->isValid()) {
			    
				    $fileHandler = fopen($requestFile->path(),"r");
		            
		            //getting the columns name 
		            $columns = fgetcsv($fileHandler);
				    
				    //while loop to get all rows data into $rows array
				    while(!feof($fileHandler)){
		                $rows[] = fgetcsv($fileHandler);  
				    }
                     
                    array_pop($rows);
   
		            foreach($rows as $key => $value){

	                   $newArray = array_combine($columns,$value);
	                    
	                      if(!DB::table('files')->insert($newArray)){
	                      	echo "Something went wrong!";
	                      }
		          }

	              $result = DB::table("files")
	                      ->select('date','category',DB::raw("SUM(`tax amount`) as 'totalAmount'"))
	                         ->groupby('date','category')
		          	         ->get();

		          echo $result;
		        
	              
			} //if is valid

    }//intersect 
    else{
    	echo "Something went wrong";
    	exit();
    }

  } // end of submitUpload


}
