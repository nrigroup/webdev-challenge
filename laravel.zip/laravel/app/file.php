<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class file extends Model
{
    
    public $timestamps = false;

    public $fillable = ["date", "category", "lot title", "lot location", "lot condition", "pre-tax amount", "tax name", "tax amount"];

  	 


}
