<h1>hello</h1>
<?php echo e($data1); ?>


