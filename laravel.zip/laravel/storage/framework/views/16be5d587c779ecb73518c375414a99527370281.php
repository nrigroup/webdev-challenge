  

  <?php $__env->startSection('content'); ?>

  <div class="container">
	<div class="row">
	<div class="col-md-6 col-md-offset-3 jumbotron">
	<h4>Upload Form</h4><br/>
	  <div class="well text-center">
	  <div style="display:none;" class="alert alert-danger" id="alert"></div>
	    <form class="form-inline" method="post" action="submitUpload" enctype="multipart/form-data">
	      <div class="form-group">
	          <label for="file" class="btn btn-lg btn-default">Please browse your file</label>
	         <input style="display:none" type="file" name="file" id="file">
	      </div><br/><br/>
	        <?php echo e(csrf_field()); ?>

	      <input type="submit" value="upload" class="btn btn-success"/>
	      </form>
  		
          </div>  
  		</div>

 <table class='table table-hover'>
 

  </table>

  	</div>
</div>

<?php $__env->stopSection(); ?>	
	
<?php $__env->startPush("js"); ?>
<script src="<?php echo e(asset('public/js/upload.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make("layout.template", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>