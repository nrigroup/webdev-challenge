<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route to view index page for uplaoding file
Route::get("/","uploadController@getIndex");

//Route to validate and submit file into database
Route::post("submitUpload","uploadController@submitUpload");

