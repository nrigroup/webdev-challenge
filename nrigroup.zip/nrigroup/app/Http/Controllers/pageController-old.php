<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class pageController extends Controller
{
	
    public function hello(){
		return view('bye');
	}
	
	function insert(Request $req){
		$name = $req->input('name');
		$email = $req->input('email');
		$password = $req->input('password');
		$data=array('name'=>$name, 'email'=>$email, 'password'=>$password);
		DB::table('users')->insert($data);
		
		echo "Success";
		$this->getData();
	}
	
	function getData(){
		$data['data']=DB::table('users')->get();
		
		if(count($data)>0){
			return view('insertForm',$data);
		}else{
			return view('insertForm');
		}
	}
	
	function readCSV_File(){
		
		$row = 1;
		if (($handle = fopen("../data.csv", "r")) !== FALSE) {
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
				$num = count($data);
				echo "<p> $num fields in line $row: <br /></p>\n";
				$row++;
				for ($c=0; $c < $num; $c++) {
					echo $data[$c] . "<br />\n";
				}
			}
			fclose($handle);
		}
	}
	
	function welcome_to_NRI(){
		return view('welcome_to_NRI');
	}
	
	function upload(){
		
		$file_name=basename($_FILES["fileToUpload"]["name"]);
		$target_dir = "../uploaded_data_files/";
		$target_file = $target_dir . $file_name;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
		$uploadOk = 1;
		
		
		if(isset($file_name)) {
			//Check File Size
			if($_FILES["fileToUpload"]["size"] > 52428800) { //50 MB (size is also in bytes)
				// File too big
				$uploadOk = 0;
				echo "Files larger than 50MB can not be uploaded"; //File is too big";
			}else{
				$uploadOk = 1;
			} 
			//Check FIle Type
			// Allow certain file formats
			if($imageFileType != "csv" ) {
				echo "Sorry, only csv files are allowed.";
				$uploadOk = 0;
			}
		}

		// Check if $uploadOk is set to 0 by an error
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
		} else {
			if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
			} else {
				echo "Sorry, there was an error uploading your file.";
			}
		}

		$this->welcome_to_NRI();
	}
}
