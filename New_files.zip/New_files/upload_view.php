<?php
if(isset($_POST['submit'])) {
	
	if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
			
		$target_dir = "uploads/";
		
		$target_file = $target_dir . basename($_FILES["file"]["name"]);
		
		$file_ext = pathinfo($target_file,PATHINFO_EXTENSION);
		
		require_once($_SERVER['DOCUMENT_ROOT']."/main_db.php");	
		$main_db=new Main_db;
		
		//Only csv file allowed
		if($file_ext=='csv'){
			
			//check if file already exist or add date time so that there is no 'file already exist error'
			
			$inventory_filename = "inventory_".date('m-d-Y_hia').".csv";
			
			// Move file to upload folder.
			
			move_uploaded_file($_FILES["file"]["tmp_name"], $target_dir . $inventory_filename);
		
			//Import uploaded file to Database
			echo "Importing File.  \n\n";				
			
			$result=$main_db->import_inventry_file($inventory_filename);
			
			echo 'Total number of rows imported '.$result;
		
		}else	
			echo 'Invalid file format';
	}
}
?>


<!DOCTYPE html>
<html>
	<head>
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <script>
	  	function check_file(){
			var file_name = $("#filename").val();
		
			if(!(file_name)){
				alert("No file selected for upload");
				return false;
			}else
				return true;
		}
	  
	  
	  </script>
	</head>
	<body>
		<div class="container">
            <form action="" method="post" enctype="multipart/form-data" class="form-horizontal" >
                
                <div class="form-group">
                    <label class="control-label col-sm-4" for="filename">Select CSV file to Upload:</label>
                    <div class="col-sm-5">
                      <input type="file" class="form-control" name="filename" id="filename">
                    </div>
                </div>
                <div class="form-group"> 
                    <div class="col-sm-offset-4 col-sm-5">
                      <button type="submit" name="submit" class="btn btn-success" onclick="return check_file();">Upload CSV</button>
                    </div>
                </div>
                
                
            </form>
		</div>
	</body>
</html>


