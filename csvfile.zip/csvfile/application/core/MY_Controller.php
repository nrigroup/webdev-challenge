<?php
class MY_Controller extends CI_Controller
	{
		function __construct()
			{
				parent::__construct();$this->load->library('session');
				if($this->session->userdata('user'))
					{
						$session_data = $this->session->userdata('user');
						$this->data['username'] = $session_data['username'];
						$this->data['id'] = $session_data['id'];
						$this->data['gid']=$session_data['gid'];
						$this->db->where('rights_group_id', $session_data['gid']);
						$fg=$this->db->get('tbl_rights_groups');
						$gh=$fg->result();
						foreach( $gh as $col1)
							{
								$a = $col1->rights_comp;
								$query=$this->db->get_where('tbl_components',array("id"=>$a));
								$sql=$query->result();
								$this->data['components'] = '';
								foreach($sql as $row) {
								$b=$row->controller; 
								$bArr = explode('/', $b);
								
								$this->data[$bArr[0]]=$col1->rights_add.",".$col1->rights_edit.",".$col1->rights_delete.",".$col1->rights_enable;
								}
								
							}
					}
			}
			
			public function check_duplicate($titleToMatch, $id)
			{		
				$records = explode(",", $id);
				$field_id = $records[0];
				$table_name = $records[1];
				$field_to_check = $records[2];
				
				$result = $this->commonfunctions_model->check_duplicate_record($titleToMatch, $field_id, $table_name, $field_to_check);
				
				if($result == 1)
					return TRUE;
				else
				{
					$this->form_validation->set_message('check_duplicate', $result);
					return FALSE;
				}	
			}
	}
	?>