<div class="container-fluid">
    <div class="row-fluid">
        <div class="span9" id="content">

            <!-- block -->
            <div class="block">
                <div class="navbar navbar-inner block-header">
                    <div class="muted pull-left"><strong>View CSV File Records</strong></div>
                    <div class="muted pull-right"> <a class="brand" href="<?php echo base_url('index.php/home');?>">  Upload CSV again</a> </div>
                </div>
                <div class="block-content collapse in">
                    <div class="span12">
                            <?php foreach($files as $row)
                            {?>
                        	<div>
                                        File Name:<?php echo $row->name;?>
                            </div>

                            <div class="control-group">
                                <h4>Total spending per category</h4>
                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Category</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($record_per_category as $rowCat)
                                              {
                                                 ?>
                                                   <tr>
                                                <td><?php echo $rowCat->category;?></td>
                                                <td><?php echo $rowCat->total;?></td>
                                            </tr>
                                                  <?php  	 } ?>
                                        </tbody>
                                    </table>
                            </div>
                             <h4>Total spending per Month</h4>
                                <div class="block-content collapse in">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Month-Year</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($record_per_month as $rowMonth)
                                              {
                                                 ?>
                                                   <tr>
                                                <td><?php echo $rowMonth->Month.'-'.$rowMonth->Year;?></td>
                                                <td><?php echo $rowMonth->total;?></td>
                                            </tr>
                                                  <?php  	 } ?>
                                        </tbody>
                                    </table>
                            </div>
                            <?php }?>
                    </div>
                </div>
            </div>
                     	<!-- /block -->
        </div>
                     <!-- /validation -->
    </div>
</div>