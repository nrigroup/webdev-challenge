<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <base href="<?= $this->config->item('base_url') ?>" />
    <title>NRI Web Development Challenge</title>
     <!-- Bootstrap -->
     <link href="<?= $this->config->item('base_url') ?>bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
     <link href="<?= $this->config->item('base_url') ?>bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
     <link href="<?= $this->config->item('base_url') ?>assets/styles.css" rel="stylesheet" media="screen">


</head>

<body>
 <!-- START OF HEADER -->

    <div class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container-fluid">

                    	<img src="<?php echo base_url("images/icon.png"); ?>" align="absmiddle" border="0" />&nbsp;&nbsp;<span style="color:#53b851">NRI </span> <span style="color:#4471b5">Web Development Challenge</span>

            </div>
        </div>
    </div>
        
 <!-- END OF HEADER -->