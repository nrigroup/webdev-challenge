        <div>
            <hr>
                <footer style="padding-left:20px;">
                    <p>&copy; NRI Web Development Challenge <?=date('Y')?></p>
                </footer>
        </div>     
  </body>
</html>