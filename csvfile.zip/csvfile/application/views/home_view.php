 <div class="container-fluid">
    <div class="row-fluid">
        <div class="span9" id="content">

            <!-- block -->
            <div class="block">
                <div class="navbar navbar-inner block-header">
                    <div class="muted pull-left"><strong>Upload CSV File</strong></div>
                </div>
                <div class="block-content collapse in">
                    <div class="span12">
                    <!-- BEGIN FORM-->
                     <?=form_open_multipart('home/savefile', array('id'=>'form_sample_1', 'class'=>'form-horizontal'));?>

                        <fieldset>
                        	<div>
                                        <?php
                                        //display error if name field is left blank
                                        echo validation_errors('<p style="color:red">');
                                        if(isset($_GET['success'])) print_r($_GET['success']); ?>
                            </div>

                            <div class="control-group">
                                <label class="control-label">File Name<span class="required">*</span></label>
                                <div class="controls">
                                                <?php echo form_input($module.'-name'); ?>
                                </div>
                            </div>

                            <div class="control-group">
                                <label class="control-label">Comments</label>
                                <div class="controls">
                                    <?php echo form_input($module.'-comment'); ?>
                                </div>
                            </div>

                            <div class="control-group">
                                <label class="control-label">Upload File<span class="required">*</span></label>
                                <div class="controls">
                                    <input type="file" name="<?=$module?>-file"  /><br><i>upload only csv files not exceeding 2MB</i>
                                </div>
                            </div>

  							<div class="form-actions">
  								<button type="submit" class="btn btn-primary">Submit</button>
  							</div>
                        </fieldset>
                    <?=form_close()?>

                    <!-- END FORM-->
                    </div>
                </div>
            </div>
                     	<!-- /block -->
        </div>

    </div>
</div>