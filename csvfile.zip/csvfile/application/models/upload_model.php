<?php
class Upload_model extends CI_Model
{
    //Query add the records of csvfiles
    function add($record = array())
    {
		$record['created'] = date("Y-m-d H:i:s");
		if (!$this->db->insert('tbl_csvfiles', $record))
		{
			return FALSE;
		}

		return $this->db->insert_id();
    }

    //Query add the contents of csvfiles with unique id of CSVfile
    function add_records($record = array())
    {
         $record['date'] = date($record['date']);
		if (!$this->db->insert('tbl_records', $record))
		{
			return FALSE;
		}

		return $this->db->insert_id();
    }

    //Query to fetch the details of csv files uploaded
    function view_files($id)
	{
	    $this->db->where('id',$id);
		$query=$this->db->get('tbl_csvfiles');
		return $query->result();
	}

    //Query displays the total spending amount per-category.
	function view_by_category($id)
	{

        $this->db->select('category, SUM(pre_tax_amount + tax_amount ) as total');
        $this->db->where('file_id',$id);
        $this->db->group_by('category');
        $this->db->order_by('total', 'desc');
        $query = $this->db->get('tbl_records');
        return $query->result();
	}

    //Query displays the total spending amount per-month
    function view_by_month($id)
	{

        $this->db->select('MONTH(date) as Month, YEAR(date) as Year, SUM(pre_tax_amount + tax_amount ) as total');
        $this->db->where('file_id',$id);
        $this->db->group_by('YEAR(date), MONTH(date)');
        $this->db->order_by('total', 'desc');
        $query = $this->db->get('tbl_records');
        return $query->result();
	}
	
}
?>
