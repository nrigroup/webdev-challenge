<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends MY_Controller {

function __construct()
	{
		parent::__construct();
        $this->controller_name = $this->router->fetch_class();
        $this->load->model('upload_model','',TRUE);
		$this->method_name = $this->router->fetch_method();
    	$this->_module = 'csvfile' ;
        $this->path = $this->controller_name;
        $this->_model = 'upload_model';

	}

function index()
	{
       $data['module']=$this->_module;
    	$this->load->view('header_view');
    	$this->load->view('home_view',$data);
    	$this->load->view('footer_view');
	}

//Upload file and save the contents to database
function savefile()
	{
       	$model = $this->_model;

		if(empty($_POST))
			redirect($this->_module);

		$this->form_validation->set_rules($this->_module.'-name', 'File name', 'trim|required|alpha|min_length[2]|max_length[20]');

	   	if($this->form_validation->run() == FALSE)
		{
			$this->index();
		}
		else
		{
			 $config['upload_path']          = './uploads/';
			$config['allowed_types']        = 'csv';
			$config['max_size']             = 2048;
			$config['file_name']        = $this->input->post($this->_module.'-name').'.csv';
			$config['overwrite']             = TRUE;


			 $this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('csvfile-file'))
                {
                        $error = array('error' => $this->upload->display_errors());

                      $err_message = implode(" ",$error);
					  redirect($this->path.'?success='.$err_message);
                }
			else
                {
                    $data = array('upload_data' => $this->upload->data());

					$records = array();

					foreach ($_POST as $k => $v)
					{
						$v = $this->input->post($k);

						if(strpos($k, '-'))
						{
							list ($prefix, $field_parts) = explode('-', $k, 2);
							//echo $prefix;exit;

							switch($k)
							{
								case strpos($k, $prefix.'-'):
								{
									if($prefix == 'csvfile')
										$records[$field_parts] = $v;

									break;
								}
							}
						}
					}
                  //We have added the name and comments into the tbl_csvfile
				$ins_id = $this->$model->add($records);
				if($ins_id >0)
				{

                //$file_path =  $config['upload_path'].'mandeep.csv';
                $file_path =  $config['upload_path'].$config['file_name'];     //get csv file name
                $this->load->library('CSVReader');           //load csvreader library from application/libraries
                $csvData = $this->csvreader->parse_file($file_path);            //path to csv file
               // print_r($csvData);

               //Loop through each row of CSV
                 foreach($csvData as $key=>$value)
                 {
                     //echo $key.' = '.$value['date'].'<Br>';

                     //get data in DB format
                     $date_parts = explode('/', $value['date']);
                     $formated_date  = "$date_parts[2]-$date_parts[0]-$date_parts[1]";

                     //create array of csv content to insert into DB
                     $csv_records['date'] =   $formated_date;
                     $csv_records['category'] =   $value['category'];
                     $csv_records['lot_title'] =   $value['lot title'];
                     $csv_records['lot_location'] =   $value['lot location'];
                     $csv_records['lot_condition'] =   $value['lot condition'];
                     $csv_records['pre_tax_amount'] =   $value['pre-tax amount'];
                     $csv_records['tax_name'] =   $value['tax amount'];
                     $csv_records['tax_amount'] =   $value['tax amount'];
                     $csv_records['file_id'] =   $ins_id;

                     //Insert the records into DB through the model into tbl_records, this table stores the
                     //unique id of the csvfile from tbl_csvfiles as file_id
                    $record_id = $this->$model->add_records($csv_reuords);

                 }
                  redirect($this->path.'/records_added?id='.	$ins_id);      //Redirect to records view to display from db

				}
				else
					redirect($this->path.'?success=0');
			}
		}
	}

    //Display the records after adding to database
	function records_added()
	{
    //echo $_GET['id'];
    $model = $this->_model;
	   $data['files'] = $this->$model->view_files($_GET['id']);
	   $data['record_per_category']=$this->$model->view_by_category($_GET['id']); //to fetch per category
       $data['record_per_month']=$this->$model->view_by_month($_GET['id']);   //to fetch per month

		$this->load->view('header_view');
		$this->load->view('records_view',$data);   //pass all the fetched data to the records view to display
		$this->load->view('footer_view');
	}
}



?>
