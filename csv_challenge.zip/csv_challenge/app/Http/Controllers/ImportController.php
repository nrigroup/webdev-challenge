<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Import;

class ImportController extends Controller
{
    public function import()
    {
       return view('imports') ;
    }
    
    public function store()
    {
        
        //Get the path of the file
       $path = request('csv_file')->getRealPath();       
       
       //Open the file
       $file = fopen($path, "r");
       
       //Get the header
       $header=fgetcsv($file);

       //Get the contents and save to database
       while($content=fgetcsv($file))
       {
            $date = date("Y-m-d",strtotime(str_replace('/','-',$content[0])));
            Import::create([
                'date'=>$date,
                'category'=>$content[1],
                'lot title'=>$content[2],
                'lot location'=>$content[3],
                'lot condition'=>$content[4],
                'pre-tax amount'=>$content[5],
                'tax name'=>$content[6],
                'tax amount'=>$content[7] 
            ]);           
          
       }
       
       //Redirect the page to /display
       return redirect('/display');

    }
    
    public function display()
    {
        //Select tax amount, date with format m-Y, and category
        $data = \DB::table('imports')->selectRaw("sum(`tax amount`) as `sum`, DATE_FORMAT(`date`, '%b-%Y') as `month`, `category`");
        
        //Group the results by month and category, and order by month and category
        $data = $data->groupBy('month','category')->latest('date')->orderBy('category');
        
        //Get tax amount grouped by month and category
        $data = $data->get();
        
        //Get the sum of tax amount
        $total=\DB::table('imports')->sum('tax amount');
        
        //Return the view /display
        return view('display', compact('data','total')) ;

    }
}
