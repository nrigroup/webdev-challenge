@extends('layout.welcome')
@section('body-content')

<body>
    <!-- Message -->
    @if(Session::has('message'))
    <p>{{ Session::get('message') }}</p>
    @endif

    <!-- Form -->
    <div class="table ">
        <div class="col-md-12">
            <br />
            <div class="d-block text-center bg-danger p-2 text-white border border-black">
                <h3>Purchase data as per total spending amount per-month and per-category.</h3>
            </div>
            <table class="table table-bordered table-striped text-center">
                <thead class="table table-primary">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Category</th>
                        <th scope="col">Year/Month</th>
                        <th scope="col">Total Spending</th>
                    </tr>
                </thead>
                <tbody class="table table-bordered">
                    @foreach($data as $key => $value)
                    <tr>
                        <td>{{ $key+1 }}</td>
                        <td>{{ $value->category }}</td>
                        <td>{{ $value->year }} / {{ $value->month }}</td>
                        <td>{{ $value->totoal_amount }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>

        </div>
    </div>
    @endsection()