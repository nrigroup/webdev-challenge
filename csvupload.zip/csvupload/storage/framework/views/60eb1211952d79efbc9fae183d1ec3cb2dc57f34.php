<?php $__env->startSection('body-content'); ?>
<!-- Form -->
<form method='post' action='<?php echo e(route('purchase.import')); ?>' enctype='multipart/form-data'>
    <?php echo e(csrf_field()); ?>

    <div class="jumbotron text-center mt-0">
        <h1>
            NRI INDUSTRIAL SALES INC. </h1>
        <h5>WE PROVIDE BUSINESSES WITH SOLUTIONS TO HELP THEM
            RECOVER CAPITAL FROM USED AND SURPLUS INDUSTRIAL ASSETS.</h5>
        <hr class="my-4">
        <h5>Please Upload your csv file below</h5>
        <hr class="my-4">
        <p class="lead">
            <input class="text-center" type='file' name='file'>

            <input class="btn btn-primary ml-0" type='submit' name='submit' value='Submit'>
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/csvupload/resources/views/layout/index.blade.php ENDPATH**/ ?>