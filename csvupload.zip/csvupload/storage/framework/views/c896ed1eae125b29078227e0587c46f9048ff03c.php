<?php $__env->startSection('body-content'); ?>

<body>
    <!-- Message -->
    <?php if(Session::has('message')): ?>
    <p><?php echo e(Session::get('message')); ?></p>
    <?php endif; ?>

    <!-- Form -->
    <div class="table ">
        <div class="col-md-12">
            <br />
            <div class="d-block text-center bg-danger p-2 text-white border border-black">
                <h3>Purchase data as per total spending amount per-month and per-category.</h3>
            </div>
            <table class="table table-bordered table-striped text-center">
                <thead class="table table-primary">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Category</th>
                        <th scope="col">Year/Month</th>
                        <th scope="col">Total Spending</th>
                    </tr>
                </thead>
                <tbody class="table table-bordered">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($value->category); ?></td>
                        <td><?php echo e($value->year); ?> / <?php echo e($value->month); ?></td>
                        <td><?php echo e($value->totoal_amount); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/csvupload/resources/views/layout/statistics.blade.php ENDPATH**/ ?>