<?php

namespace App\Http\Controllers;
use App\purchasedata;
use Illuminate\Http\Request;
use Session;


class purchasecontroller extends Controller
{
    //
   
    public function index(){
        return view('layout.index');
      }

    
      public function uploadFile(Request $request){
    
        if ($request->input('submit') != null ){
    
          $file = $request->file('file');
          //print_r($file);die;
    
          // File Details 
          $filename = $file->getClientOriginalName();
          $extension = $file->getClientOriginalExtension();
          $tempPath = $file->getRealPath();
          $fileSize = $file->getSize();
          $mimeType = $file->getMimeType();
    
          // Valid File Extensions
          $valid_extension = array("csv");
    
          // 2MB in Bytes
          $maxFileSize = 2097152; 
    
          // Check file extension
          if(in_array(strtolower($extension),$valid_extension)){
    
            // Check file size
            if($fileSize <= $maxFileSize){
    
              // File upload location
              $location = __DIR__ . '/../../../upload';
              
              // Upload file
              $file->move($location,$filename);
    
              // Import CSV to Database
              //$filepath = public_path("upload/".$filename);
              //echo $filepath;die;
    
              // Reading file
              $file = fopen($location.'/'.$filename,"r");
    
              $importData_arr = array();
              $i = 0;
    
              while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                 $num = count($filedata );
                 
                 
                 if($i == 0){
                    $i++;
                    continue; 
                 }
                 for ($c=0; $c < $num; $c++) {
                    $importData_arr[$i][] = $filedata [$c];
                 }
                 $i++;
              }
              fclose($file);

              //echo '<pre>';print_r($importData_arr);echo  '</pre>';die;
    
              // Insert to MySQL database
              foreach($importData_arr as $importData){
    
                $purchase_date = date('Y-m-d',strtotime($importData[0]));
                $insertData = array(
                   "date"=>$purchase_date,
                   "category"=>$importData[1],
                   "lot_title"=>$importData[2],
                   "lot_location"=>$importData[3],
                   "lot_condition"=>$importData[4],
                   "pre_tax_amount"=>$importData[5],
                   "tax_name"=>$importData[6],
                   "tax_amount"=>$importData[7]);
                   purchasedata::insertData($insertData);
                    
                
              }
    
              Session::flash('message','Import Successful.');

            //  
            }else{
              Session::flash('message','File too large. File must be less than 2MB.');
            }
    
          }else{
             Session::flash('message','Invalid File Extension.');
          }
    
        }
    
        // Redirect to index
        return redirect()->action('purchasecontroller@index');
      }


      function statistics(){

        $data = purchasedata::getStatistics();

        //echo "<pre>";print_r($data);echo "</pre>";
        //die;
        return view('layout.statistics',['data'=>$data]);
      }
 }