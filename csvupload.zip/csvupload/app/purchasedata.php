<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class purchasedata extends Model
{
    public static function insertData($data){

        $value=DB::table('purchases')->where('date', $data['date'])->get();
        if($value->count() == 0){
           DB::table('purchases')->insert($data);
        }
     }


    public static function getStatistics(){
        //$data = DB::table('purchases')->get();

        $data = DB::select( DB::raw("SELECT category,Month(date) AS month,Year(date) AS year,sum(pre_tax_amount) as totol_amount FROM `purchases` GROUP BY category,year,month ASC") );

        return $data;
    }

    // public static function getdata($data){

    //    // SELECT category,date,sum(pre_tax_amount) as totoal_amount FROM `purchases` 
    //    // GROUP BY category,EXTRACT(Month from date )

    //     $values -> select(DB::raw('category'),DB::raw('date'),DB::raw('sum(pre_tax_amount) as `Total Spending`' ))
    //            ->groupby('category',EXTRACT('month from date'))
    //            ->get();
    // }
}